#define DR_FLAC_IMPLEMENTATION
#include "../../dr_flac.h"

#include "../common/dr_common.c"

int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;
    return 0;
}
