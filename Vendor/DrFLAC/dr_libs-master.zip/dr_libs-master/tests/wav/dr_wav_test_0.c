#define DR_WAV_IMPLEMENTATION
#include "../../dr_wav.h"

#include "../common/dr_common.c"

int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;
    return 0;
}
